from setuptools import setup

setup(
    name='hand_slide_path',
    version='0.0.1',
    author='huruwo',
    author_email='1458476478@qq.com',
    url='https://github.com/HuRuWo/HandSlidePath',
    description=u'返回手滑路径',
    packages=['hand_slide_path'],
    install_requires=[],
    entry_points={
        'console_scripts': [

        ]
    }
)